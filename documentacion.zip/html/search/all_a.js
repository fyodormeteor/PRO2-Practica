var searchData=
[
  ['obtener_5fcantidad_67',['obtener_cantidad',['../classProducto.html#a8a1e16fa6eb7ec01fae70a608d069df9',1,'Producto']]],
  ['obtener_5fexceso_68',['obtener_exceso',['../classProducto.html#a89b2c611c4021a44510bed631e4ec313',1,'Producto']]],
  ['obtener_5fnecesidad_69',['obtener_necesidad',['../classProducto.html#ac8ba589a126fbb5da49ea11c03b7ccda',1,'Producto']]],
  ['operator_2b_3d_70',['operator+=',['../classProducto.html#abe4473c1c3cce1c4944e0a43992f07e1',1,'Producto']]]
];
