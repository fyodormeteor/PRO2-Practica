var searchData=
[
  ['infoviaje_97',['InfoViaje',['../structBarco_1_1InfoViaje.html',1,'Barco']]]
];
