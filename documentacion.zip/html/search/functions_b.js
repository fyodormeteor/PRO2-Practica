var searchData=
[
  ['quitar_5finventario_158',['quitar_inventario',['../classCiudad.html#a29e99189ae075d724c3e5f272dbdf2a2',1,'Ciudad']]],
  ['quitar_5finventario_5fde_5fciudad_159',['quitar_inventario_de_ciudad',['../classRio.html#ac5e3b1e020c059cde92323bb0bfad946',1,'Rio']]]
];
