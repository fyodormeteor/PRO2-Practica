var searchData=
[
  ['infoviaje_139',['InfoViaje',['../structBarco_1_1InfoViaje.html#a32e56964d37b38362b2587fa3af3c08c',1,'Barco::InfoViaje']]]
];
