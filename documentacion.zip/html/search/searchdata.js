var indexSectionsWithContent =
{
  0: "abcdehilmnopqrv",
  1: "bcipr",
  2: "bcpr",
  3: "abcdehilmopqrv",
  4: "abcinpv",
  5: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "defines"
};

