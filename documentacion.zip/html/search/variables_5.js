var searchData=
[
  ['peso_5ftotal_182',['peso_total',['../classCiudad.html#acca02fdeea122b66162683bdb4a233e0',1,'Ciudad']]]
];
