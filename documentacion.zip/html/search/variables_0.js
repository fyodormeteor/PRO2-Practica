var searchData=
[
  ['altura_168',['altura',['../structBarco_1_1InfoViaje.html#ae0a7f1bbe0ad4fdd0187f6fb228c97ae',1,'Barco::InfoViaje']]]
];
